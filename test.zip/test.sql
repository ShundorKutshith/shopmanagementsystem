-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 23, 2021 at 09:47 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `imports1`
--

CREATE TABLE `imports1` (
  `ID` int(11) NOT NULL,
  `NAME` text NOT NULL,
  `PRICE` double NOT NULL,
  `QUANTITY` int(11) NOT NULL,
  `SIZE` double NOT NULL,
  `UNIT` text NOT NULL,
  `DATETIME` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `imports1`
--

INSERT INTO `imports1` (`ID`, `NAME`, `PRICE`, `QUANTITY`, `SIZE`, `UNIT`, `DATETIME`) VALUES
(1, 'Sauce', 103, 30, 300, 'gm', '2021-03-08 02:15:33'),
(2, 'Sprite', 65, 30, 1, 'L', '2021-03-08 02:17:12'),
(3, 'djf', 3, 3, 3, 'sjfl', '2021-03-08 04:24:55'),
(4, 'Meridian', 15, 40, 100, 'gm', '2021-03-08 12:08:40'),
(5, 'Seven Up', 70, 20, 1, 'L', '2021-03-08 12:14:44'),
(6, 'howfd', 39, 39, 200, 'gm', '2021-03-08 13:16:47'),
(7, 'Surfexcel', 15, 50, 100, 'gm', '2021-03-20 21:58:31'),
(8, 'Chips', 20, 10, 30, 'gm', '2021-03-22 06:58:28'),
(9, 'Sprite', 50, 30, 1, 'l', '2021-03-22 07:03:55'),
(10, 'chocolate', 20, 25, 200, 'gm', '2021-03-22 10:34:59');

-- --------------------------------------------------------

--
-- Table structure for table `imports2`
--

CREATE TABLE `imports2` (
  `ID` int(11) NOT NULL,
  `NAME` text NOT NULL,
  `PRICE` double NOT NULL,
  `QUANTITY` int(11) NOT NULL,
  `SIZE` double NOT NULL,
  `UNIT` text NOT NULL,
  `DATETIME` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `imports2`
--

INSERT INTO `imports2` (`ID`, `NAME`, `PRICE`, `QUANTITY`, `SIZE`, `UNIT`, `DATETIME`) VALUES
(1, 'djf', 3, 3, 3, 'sjfl', '2021-03-08 04:24:55'),
(2, 'Meridian', 15, 40, 100, 'gm', '2021-03-08 12:08:40'),
(3, 'Seven Up', 70, 20, 1, 'L', '2021-03-08 12:14:44'),
(4, 'howfd', 39, 39, 200, 'gm', '2021-03-08 13:16:48'),
(5, 'Surfexcel', 15, 100, 100, 'gm', '2021-03-20 21:58:31'),
(6, 'Chips', 20, 10, 30, 'gm', '2021-03-22 06:58:28'),
(7, 'Sprite', 50, 30, 1, 'l', '2021-03-22 07:03:55'),
(8, 'chocolate', 20, 30, 200, 'gm', '2021-03-22 10:34:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `imports1`
--
ALTER TABLE `imports1`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `imports2`
--
ALTER TABLE `imports2`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `imports1`
--
ALTER TABLE `imports1`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `imports2`
--
ALTER TABLE `imports2`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
